
provider "azurerm" {
  features {}
}
