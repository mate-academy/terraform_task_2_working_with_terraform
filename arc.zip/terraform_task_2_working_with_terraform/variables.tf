variable "azregion" {
  type    = string
  default = "West Europe"
}

variable "rg" {
  type    = string
  default = "terraform_task_2_rg"
}

variable "storage_acc" {
  type    = string
  default = "terraform_task_2_storage_account"
}

variable "container" {
  type    = string
  default = "terraform_task_2_Container23"
}

variable "blob_name" {
  type    = string
  default = "terraform_task_2_StorageBlob.zip"
}

